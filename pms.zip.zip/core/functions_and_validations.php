<?php


# add to cart


function addtocart($product_id, $product_name, $product_price, $product_quantity)
{
    $_SESSION['cart'][] = [
        'product_id' => $product_id,
        'product_name' => $product_name,
        'product_price' => $product_price,
        'product_quantity' => $product_quantity,
    ];
    $file = fopen('../Data/cart.csv', 'a');

    $product_store = $product_id . ',' . $product_name . ',' . $product_price . ',' . $product_quantity;
    fwrite($file, $product_store);

    fclose($file);
}







?>